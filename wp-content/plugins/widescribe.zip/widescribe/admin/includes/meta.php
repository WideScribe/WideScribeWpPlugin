<div class="t_about t_product t_service t_news t_sitemap t_blog t_full t_gallery t_search t_login t_contact t_portfolio post_edit_page t_default t_mpopular">

    <h2>You are charging</h2> 
    You are charging 2 kr for this article using WideScribe
    
    <h2>Status</h2> 
    The article was updated on WideScribe at the same time as on your CMS.
    
 
    
	</div>