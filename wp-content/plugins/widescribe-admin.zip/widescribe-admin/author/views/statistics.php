<div class="wrap">
    <h2><?php _e('Statistics', $this->plugin->name); ?> </h2>
    <div class="updated fade"><p>Under development</p></div>  
</div>



