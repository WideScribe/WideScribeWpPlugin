=== Debug "unexpected output" During Plugin Activation ===

Contributors: David Wells
Donate link: mailto:david@inboundnow.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: debug, plugin activation errors, wordpress developer plugin
Requires at least: 3.5
Tested up to: 3.6
Stable Tag: 1.9.1

This developer plugin allows for easy debugging of those ambiguous "The plugin generated ### characters of unexpected output during activation. If you notice “headers already sent” messages, problems with syndication feeds or other issues, try deactivating or removing this plugin." Hope it helps you solve your headaches!

== Description ==

This developer plugin allows for easy debugging of those ambiguous "The plugin generated ### characters of unexpected output during activation. If you notice “headers already sent” messages, problems with syndication feeds or other issues, try deactivating or removing this plugin." Hope it helps you solve your headaches!

== Usage ==

Install this plugin and then activate your plugin you are trying to debug.

== Changelog ==

= 1.0.1 =

Released
