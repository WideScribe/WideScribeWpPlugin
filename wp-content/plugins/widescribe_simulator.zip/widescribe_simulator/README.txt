=== WideScribe Simulator ===
Contributors: Jens Tandstad
Tags: WideScribe
Requires at least: 3.2
Tested up to: 4.0
Stable tag: 1.1

A simple WordPress widget for sharing a few of your social networks.

== Description ==

This widget is used to demonstrate the <a href="http://github.com/tommcfarlin/WordPress-Widget-Boilerplate">WordPress Widget Boilerplate</a>.

It was also used in the WpTuts article <a href="http://wp.tutsplus.com/tutorials/widgets/writing-maintainable-wordpress-widgets-part-1-of-2/">Writing Maintainable WordPress Widgets</a>.

== Installation ==

1. Upload the plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to Appearance > Widgets
4. Drop the widget on your side and continue!

== Changelog ==

= 1.1 =
* Updating constant references
* Changes the order in which localization definitions are loaded

= 1.0 =
* Initial release
